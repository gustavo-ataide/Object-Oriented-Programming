//
//  main.hpp
//  CPP004
//
//  Created by guga on 26/09/23.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
