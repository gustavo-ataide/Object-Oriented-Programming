#include "complex.hpp"

Complex::Complex(float real, float imaginaria){
    this->real = real;
    this->imaginaria = imaginaria;
}
