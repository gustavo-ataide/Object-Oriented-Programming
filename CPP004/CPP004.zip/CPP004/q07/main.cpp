//#include "Bruxo.hpp"
//#include "Capa.hpp"
//#include "varinha.hpp"
//#include "expresso.hpp"
//#include <iostream>
//#include <string>
//using namespace std;
//
//int main() {
//    ExpressoHogwarts expresso;
//    Bruxo harry("Harry","Grifinoria","expecto patronum");
//    cout << "Embarcando..." << endl;
//     
//      expresso << harry;
//      expresso << Bruxo("Rony","Grifinoria","wingardium leviosa");
//      expresso << Bruxo("Hermione","Grifinoria","flipendo");
//
//      expresso << Bruxo("Malfoy","Sonserina","cruciatus");
//
//      cout << expresso;
//
//      cout << "Partindo..." << endl;
//      cout << "Viajando..." << endl;
//     
//      cout << "Chegando..." << endl;
//      cout << "Desembarcando..." << endl;
//
//    
//      expresso >> "Malfoy";
//      expresso >> harry;
//      expresso >> Bruxo("Rony","Grifinoria","wingardium leviosa");
//      expresso >> Bruxo("Hermione","Grifinoria","flipendo");
//
//      cout << expresso;
//     
//
//    
//    return 0;
//}
