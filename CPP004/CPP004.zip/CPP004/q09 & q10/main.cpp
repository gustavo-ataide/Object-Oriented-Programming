//#include "HugeInteger.hpp"
//#include <iostream>
//
//using namespace std;
//
//int main() {
//    char n1[40] = "1";
//    char n2[40] = "2";
//    char n3[40] = "3";
//    HugeInteger num1(n1);
//    HugeInteger num2(n2);
//
//    // Testando a sobrecarga do operador +
//    HugeInteger resultado1 = num1 + num2;
//    cout << "Resultado da adição: " << resultado1 << endl;
//
//    // Testando a sobrecarga do operador -
//    HugeInteger resultado2 = num1 - num2;
//    cout << "Resultado da subtração: " << resultado2 << endl;
//
//    // Testando a sobrecarga do operador *
//    HugeInteger resultado3 = num1 * num2;
//    cout << "Resultado da multiplicação: " << resultado3 << endl;
//
//    // Testando a sobrecarga do operador /
//    HugeInteger resultado4 = num1 / num2;
//    cout << "Resultado da divisão: " << resultado4 << endl;
//
//    // Testando a sobrecarga do operador +=
//    num1 += num2;
//    cout << "Resultado da adição com atribuição: " << num1 << endl;
//
//    // Testando a sobrecarga do operador -=
//    num1 -= num2;
//    cout << "Resultado da subtração com atribuição: " << num1 << endl;
//
//    // Testando a sobrecarga do operador *=
//    num1 *= num2;
//    cout << "Resultado da multiplicação com atribuição: " << num1 << endl;
//
//    // Testando a sobrecarga do operador /=
//    num1 /= num2;
//    cout << "Resultado da divisão com atribuição: " << num1 << endl;
//
//    // Testando a sobrecarga do operador ++
//    HugeInteger num3(n3);
//    num3++;
//    cout << "Resultado do incremento: " << num3 << endl;
//    
//    num3--;
//    cout << "Resultado do incremento: " << num3 << endl;
//    
//
//    // Testando os operadores de comparação
//    cout << "Comparação num1 > num2: " << (num1 > num2) << endl;
//    cout << "Comparação num1 < num2: " << (num1 < num2) << endl;
//    cout << "Comparação num1 == num2: " << (num1 == num2) << endl;
//
//    return 0;
//}
