//#include <iostream>
//
//using namespace std;
//
//int main(void){
//    double litrostotal=0;
//    while (true){
//        int km;
//        double litros;
//        
//        cout << "Digite a quantidade de km percorridos" << endl;
//        cin >> km;
//        if (km == -1){
//            break;
//        }
//        cout << "Digite a quantidade de litros consumidos" << endl;
//        cin >> litros;
//        
//        cout << "Consumo: " << km/litros << " km/l"<< endl;
//        litrostotal += litros;
//
//    }
//    cout << "Total de combustivel consumido: " << litrostotal << endl;
//}
