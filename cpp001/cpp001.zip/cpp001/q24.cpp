//#include <iostream>
//#include <string>
//
//using namespace std;
//
//int maiuscula_sn(string palavra){
//    char alfabeto_maiusculo[] = {'A','B','C','D','E','F', 'G', 'H', 'I', 'J','K', 'L', 'M','N','O','P', 'Q','R','S','T', 'U','V', 'W', 'X','Y', 'Z'};
//    for(int i=0; i< palavra.length(); i++){
//        for (int letra = 0; letra < 26; letra ++){
//            if (palavra[i] == alfabeto_maiusculo[letra]){
//                return 1;
//            }
//        }
//    }
//    return 0;
//}
//
//int main (void){
//
//
//    string word;
//    cout << "Digite uma palavra: " << endl;
//    cin >> word;
//    int resultado = maiuscula_sn(word);
//    if(resultado == 1){
//        cout << "Possui letra maiuscula" << endl;
//    }
//    if (resultado ==0){
//        cout << "Nao possui letra maiuscula" << endl;
//    }
//
//}
