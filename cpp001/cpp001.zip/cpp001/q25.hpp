//
//  q25.hpp
//  cpp001
//
//  Created by Gustavo  Henrique on 17/08/23.
//

#ifndef q25_hpp
#define q25_hpp

#include <stdio.h>

#endif /* q25_hpp */
