//#include <iostream>
//#include <string>
//using namespace std;
//
//int main(void){
//    string frase;
//    string nova;
//    getline(cin, frase);
//    for (int i=0; i<frase.length();i++){
//        
//        if((frase.substr(i,1) != " ") and (frase.substr(i,1) != "!") and (frase.substr(i,1) != ".") and (frase.substr(i,1) != ",") and (frase.substr(i,1) != "?")){
//            nova += frase.substr(i,1);
//        }
//    }
//    cout << nova;
//    return 0;
//}
//
//
