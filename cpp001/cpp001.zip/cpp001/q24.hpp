//
//  q24.hpp
//  cpp001
//
//  Created by Gustavo  Henrique on 17/08/23.
//

#ifndef q24_hpp
#define q24_hpp

#include <stdio.h>

#endif /* q24_hpp */
