//
//  q18b.hpp
//  cpp001
//
//  Created by Gustavo  Henrique on 16/08/23.
//

#ifndef q18b_hpp
#define q18b_hpp

#include <stdio.h>

#endif /* q18b_hpp */
