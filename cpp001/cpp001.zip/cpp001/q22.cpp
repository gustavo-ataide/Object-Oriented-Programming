//#include <iostream>
//
//using namespace std;
//
//void swap (int *pont1, int *pont2){
//    int temp = *pont2;
//    *pont2 = *pont1;
//    *pont1 = temp;
//}
//
//
//int main(void){
//    int a = 5;
//    int b = 3;
//    int * n1 = &a;
//    int *n2 = &b;
//    cout << *n1 << *n2 << endl;
//    swap(n1, n2);
//    cout << *n1 << *n2 << endl;
//}
// 
