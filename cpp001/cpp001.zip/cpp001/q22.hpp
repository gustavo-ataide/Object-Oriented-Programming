//
//  q22.hpp
//  cpp001
//
//  Created by Gustavo  Henrique on 17/08/23.
//

#ifndef q22_hpp
#define q22_hpp

#include <stdio.h>

#endif /* q22_hpp */
