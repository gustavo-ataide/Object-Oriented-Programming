//#include <iostream>
//
//using std::cout,std::cin;
//
//int main() {
//    char nome[10];
//    cout << "Digite o nome do aluno:\n";
//    cin >> nome;
//    int n1, n2, n3;
//    cout << "Digite as médias no formato: X.Y X.Y  X.Y" << std::endl;
//    cin >> n1 >> n2 >> n3;
//    float media = (n1+n2+n3)/3;
//    cout << "O aluno " << nome << " obteve media: \n" <<media << std::endl;
//    return 0;
//}
