//#include <iostream>
//
//using namespace std;
//
//void swap(int &ref1, int &ref2){
//    int temp = ref1;
//    ref1 = ref2;
//    ref2 = temp;
//}
//
//int main(void){
//    int a = 3;
//    int b = 5;
//    int &num1 = a, &num2 = b;
//    cout << num1 << num2 << endl;
//    swap(num1,num2);
//    cout << num1 << num2 << endl;
//    
//}
