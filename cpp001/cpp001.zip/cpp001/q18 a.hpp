//
//  q18 a.hpp
//  cpp001
//
//  Created by Gustavo  Henrique on 16/08/23.
//

#ifndef q18_a_hpp
#define q18_a_hpp

#include <stdio.h>

#endif /* q18_a_hpp */
