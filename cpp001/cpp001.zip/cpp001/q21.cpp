//#include <iostream>
//
//using namespace std;
//
//void retorna(void){
//    static int num;
//    num ++;
//    cout << num << endl;
//}
//
//
//int main(void){
//    for (int i=0;i<3;i++){
//        retorna();
//        
//    }
//    
//}
