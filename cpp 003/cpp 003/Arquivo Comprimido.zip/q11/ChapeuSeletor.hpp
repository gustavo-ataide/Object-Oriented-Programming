#ifndef ChapeuSeletor_hpp
#define ChapeuSeletor_hpp
#include <string>
#include <stdio.h>
using namespace std;

class ChapeuSeletor{
public:
    ChapeuSeletor();
    
    void recepcionar();
    string sortearCasa();
};

#endif 
