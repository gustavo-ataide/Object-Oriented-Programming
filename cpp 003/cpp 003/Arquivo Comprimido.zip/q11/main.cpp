//#include "ChapeuSeletor.hpp"
//#include <iostream>
//using namespace std;
//
//int main() {
//    ChapeuSeletor chapeu;
//
//    chapeu.recepcionar();
//
//    for (int i = 0; i < 10; i++) {
//        string casaSorteada = chapeu.sortearCasa();
//        cout << "Aluno sorteado para a casa: " << casaSorteada << endl;
//    }
//
//    return 0;
//}
