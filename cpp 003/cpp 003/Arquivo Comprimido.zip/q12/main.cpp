//#include <iostream>
//
//#include "ArrayList.hpp"
//
//int main() {
//  ArrayList al(10);
//
//  al.add(1).add(2).add(10).add(20);
//
//  al.print();
//    
//    somaArray(al,2);
//    al.print();
//
//  return 0;
//}
