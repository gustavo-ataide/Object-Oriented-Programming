//
//  main.hpp
//  cpp 003
//
//  Created by guga on 18/09/23.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
