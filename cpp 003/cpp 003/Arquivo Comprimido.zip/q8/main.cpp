//#include "varinha.hpp"
//#include <iostream>
//#include <string>
//using namespace std;
//
//int main() {
//    // Criando uma varinha
//    Varinha minhaVarinha("Carvalho", "Fênix", 30.5);
//
//    // Exibindo os atributos da varinha
//    cout << "Atributos da Varinha:" << endl;
//    minhaVarinha.displayVarinha();
//
//    // Modificando os atributos da varinha usando os métodos set
//    minhaVarinha.setTipoDeMadeira("Olmo");
//    minhaVarinha.setNucleo("Dragão");
//    minhaVarinha.setComprimento(32.0);
//
//    // Exibindo os atributos atualizados
//    cout << "\nAtributos da Varinha Atualizados:" << endl;
//    minhaVarinha.displayVarinha();
//
//    // Obtendo os atributos da varinha usando os métodos get
//    string tipoDeMadeira = minhaVarinha.getTipoDeMadeira();
//    string nucleo = minhaVarinha.getNucleo();
//    double comprimento = minhaVarinha.getComprimento();
//
//    cout << "\nTipo de Madeira: " << tipoDeMadeira << endl;
//    cout << "Nucleo: " << nucleo << endl;
//    cout << "Comprimento: " << comprimento << endl;
//
//    return 0;
//}
