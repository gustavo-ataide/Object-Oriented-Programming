//#include "Capa.hpp"
//#include <iostream>
//#include <string>
//using namespace std;
//
//int main() {
//    string casa;
//    double tamanho;
//
//    cout << "Digite a casa da capa (grifinoria, sonserina, corvinal ou lufa-lufa): ";
//    cin >> casa;
//    cout << "Digite o tamanho da capa: ";
//    cin >> tamanho;
//
//    Capa minhaCapa(casa, tamanho);
//
//    minhaCapa.displaycapa();
//
//    // Testando os métodos set e get
//    string novaCasa;
//    double novoTamanho;
//
//    cout << "\nDigite a nova casa da capa: ";
//    cin >> novaCasa;
//    minhaCapa.setCasa(novaCasa);
//
//    cout << "Digite o novo tamanho da capa: ";
//    cin >> novoTamanho;
//    minhaCapa.setTamanho(novoTamanho);
//
//    cout << "\nAtributos da capa após a modificação:" << endl;
//    minhaCapa.displaycapa();
//
//    return 0;
//}
