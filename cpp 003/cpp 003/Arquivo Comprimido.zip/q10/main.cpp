//#include "Bruxo.hpp"
//#include "Capa.hpp"
//#include "Varinha.hpp"
//#include <iostream>
//#include <string>
//using namespace std;
//
//int main() {
//    // Criação de uma varinha
//    Varinha varinha("Carvalho", "Fênix", 30.5);
//
//    // Criação de uma capa
//    Capa capa("grifinoria", 100.0);
//
//    // Criação de um bruxo e associação da varinha e da capa
//    Bruxo harry("Harry Potter");
//    harry.pegarvarinha_laele(&varinha);
//    harry.vestircapa(&capa);
//
//    // Exibindo os atributos do bruxo
//    harry.displaymessage();
//
//    // Modificando alguns atributos do bruxo
//    harry.setCasa("corvinal");
//    harry.setFeitico_favorito("Expelliarmus");
//    harry.getCapa().setTamanho(110.0);
//
//    // Exibindo os atributos atualizados do bruxo
//    harry.displaymessage();
//
//    return 0;
//}
